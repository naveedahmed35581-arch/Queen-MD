const { cmd } = require('../inconnuboy');
const config = require('../config');

cmd({
    pattern: 'owner',
    alias: ['creator', 'dev'],
    desc: 'Show the bot owner contact',
    category: 'general',
    react: '👑'
}, async (conn, mek, m, { reply }) => {
    const number = String(config.OWNER_NUMBER || '').replace(/[^0-9]/g, '');
    await reply(`👑 *${config.OWNER_NAME || config.BOT_NAME}*\n\n📱 Owner: wa.me/${number}\n🤖 Bot: ${config.BOT_NAME}\n⚡ Prefix: ${config.PREFIX}`);
});

cmd({
    pattern: 'runtime',
    alias: ['uptime2', 'botruntime'],
    desc: 'Show bot runtime and server memory',
    category: 'general',
    react: '⏱️'
}, async (conn, mek, m, { reply }) => {
    const seconds = Math.floor(process.uptime());
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const rss = Math.round(process.memoryUsage().rss / 1024 / 1024);
    await reply(`⏱️ *QUEEN-MD Runtime*\n\n🟢 Uptime: ${days}d ${hours}h ${minutes}m\n💾 RAM: ${rss} MB\n🧩 Node.js: ${process.version}\n⚙️ Mode: ${config.WORK_TYPE || 'public'}`);
});
