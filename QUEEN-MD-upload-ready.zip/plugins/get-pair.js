const { cmd, commands } = require('../inconnuboy');
const axios = require('axios');

cmd({
    pattern: "pair",
    alias: ["getpair", "clonebot", "pair2", "pair3"],
    react: "✅",
    desc: "Get a pairing code (cooldown applies; pairing cannot be guaranteed ban-free)",
    category: "download",
    use: ".pair 923195068XXX",
    filename: __filename
}, async (conn, mek, m, {
    from,
    quoted,
    body,
    isCmd,
    command,
    args,
    q,
    isGroup,
    senderNumber,
    reply
}) => {
    try {
        // Get phone number
        const phoneNumber = q
            ? q.trim().replace(/[^0-9]/g, '')
            : senderNumber.replace(/[^0-9]/g, '');

        // Validate number
        if (!phoneNumber || phoneNumber.length < 10 || phoneNumber.length > 15) {
            return await reply(
                "❌ Please provide a valid phone number without +\n\nExample:\n.pair 923195068XXX"
            );
        }

        // This command uses a third-party pairing endpoint. Only use a service you trust.
        const response = await axios.get(
            `https://khan-zada-f3a760e88caa.herokuapp.com/code?number=${encodeURIComponent(phoneNumber)}`
        );

        if (!response.data || !response.data.code) {
            return await reply("❌ Failed to retrieve pairing code. Please try again later.");
        }

        const pairingCode = response.data.code;

        await reply(
`🦋⍣⃝🤓 QUEEN-MD 🕊\n\n🔑 Your Pair Code:\n*${pairingCode}*\n\n⚠️ Code milne ka matlab pairing complete hona nahi hai. Code sirf apne WhatsApp account par use karein. Bar-bar code request na karein; ban-free hone ki guarantee nahi hoti.`
        );

    } catch (error) {
        console.error("Pair command error:", error);
        await reply("❌ An error occurred while getting the pairing code.\nPlease try again later.");
    }
});
