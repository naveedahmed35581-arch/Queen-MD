# QUEEN-MD WhatsApp Bot

## Deployment

This project includes deployment configuration for Render, Railway, and Docker-based hosts.

### Requirements
- Node.js 22.x
- A MongoDB URI is recommended for persistent session storage and reconnect support.
- Configure secrets in your hosting provider's environment-variable settings. Do not commit `.env` or session files.

### Render
1. Push this repository to your own Git repository.
2. In Render, create a **Blueprint** from the repository containing `render.yaml`.
3. Set `SESSION_ID`, `MONGODB_URI`, and `OWNER_NUMBER` as appropriate in the service environment.
4. Check the service health at `/health` and inspect logs for WhatsApp pairing/session messages.

### Railway / Docker
Railway uses `railway.json` and `Dockerfile`. For another Docker host, build the image from this directory and provide environment variables at runtime.

### Local run
```sh
npm install
cp .env.example .env
# Edit .env with your own values
npm start
```

The HTTP health endpoint is `/health`. A healthy HTTP response does **not** by itself prove that WhatsApp is paired or that every command's external API is available.
