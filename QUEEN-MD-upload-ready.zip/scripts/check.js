const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ignored = new Set(['node_modules', '.git', 'session']);
const failures = [];
let checked = 0;

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (ignored.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.isFile() && full.endsWith('.js')) {
      try {
        new vm.Script(fs.readFileSync(full, 'utf8'), { filename: full });
        checked++;
      } catch (error) {
        failures.push({ file: path.relative(process.cwd(), full), error: error.message });
      }
    }
  }
}
walk(process.cwd());
for (const failure of failures) console.error(`FAIL ${failure.file}: ${failure.error}`);
console.log(`Checked ${checked} JavaScript files; ${failures.length} syntax error(s).`);
if (failures.length) process.exitCode = 1;
